import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NewSService {

  constructor(public _http : HttpClient) {}
detailss:any;
author:any;
// functions to get third party using api
getNews(){
  return this._http.get('http://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=9a74fd70f7a94f2fbff0db4aae7e562c');
}
getNewsDetails(ref){
  
  
  return this._http.get('http://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=9a74fd70f7a94f2fbff0db4aae7e562c');

 
}



 

getjobsearch(ref)
 {
  return this._http.get('https://jobs.github.com/positions/'+ref+'.json');


 }
}
