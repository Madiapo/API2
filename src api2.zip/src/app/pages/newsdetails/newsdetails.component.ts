import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NewSService } from 'src/app/services/new-s.service';

@Component({
  selector: 'app-newsdetails',
  templateUrl: './newsdetails.component.html',
  styleUrls: ['./newsdetails.component.scss']
})
export class NewsdetailsComponent implements OnInit {
  // declaration of variables
Ref:any;
details:any[];

  constructor(public data:NewSService,public  _route :ActivatedRoute) { }

  ngOnInit() {

// this.Ref=this._route.snapshot.paramMap.get('ref');
// this.data.getNews().subscribe(e=>{
//   this.details=e['articles'];
//   console.log(e);
// })
 this.data.getNewsDetails(this.Ref).subscribe(e=>{
   this.details=e['articles']
   console.log(e)
 })
  }

}
