import { Component, OnInit } from '@angular/core';
import{NewSService}from'src/app/services/new-s.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-searchpage',
  templateUrl: './searchpage.component.html',
  styleUrls: ['./searchpage.component.scss']
})
export class SearchpageComponent implements OnInit {
  Ref:any;
  details:any;

  constructor(public data:NewSService,public _route :ActivatedRoute) { }

  ngOnInit() {
this.data.getjobsearch(this.Ref).subscribe(e=>{
  this.details=e['articles'];
  console.log(e);
})

  }

}
