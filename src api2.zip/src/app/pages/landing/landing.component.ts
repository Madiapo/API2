import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import{NewSService}from'src/app/services/new-s.service';
import { NewsdetailsComponent } from '../newsdetails/newsdetails.component';
;@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent implements OnInit {
details:any;
  constructor(public _data:NewSService) { }

  ngOnInit() {
this._data.getNews().subscribe(e=>{
  console.log(e)
this.details=e['articles'];

})

  }

}
