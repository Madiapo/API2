import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{NewSService}from'./services/new-s.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LandingComponent } from './pages/landing/landing.component';
import { NewsdetailsComponent } from './pages/newsdetails/newsdetails.component';
import{HttpClientModule}from '@angular/common/http';
import { from } from 'rxjs';
import { SearchpageComponent } from './pages/searchpage/searchpage.component';


 
@NgModule({
  declarations: [
    AppComponent,
    LandingComponent,
    NewsdetailsComponent,
    SearchpageComponent,
     SearchpageComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
  ],
  providers: [NewSService],
  bootstrap: [AppComponent]
})
export class AppModule { }
